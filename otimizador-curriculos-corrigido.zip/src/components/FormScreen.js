import React from 'react';
import FileUploader from './FileUploader';

const FormScreen = ({ formData, file, onInputChange, onFileChange, onSubmit, onBack }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-blue-800">Informações da Vaga</h2>

      <form onSubmit={onSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Cargo Pretendido *</label>
            <input
              type="text"
              name="cargo"
              value={formData.cargo}
              onChange={onInputChange}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
              placeholder="Ex: Gerente de Projetos"
            />
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Nível *</label>
            <select
              name="nivel"
              value={formData.nivel}
              onChange={onInputChange}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Selecione...</option>
              <option value="junior">Júnior</option>
              <option value="pleno">Pleno</option>
              <option value="senior">Sênior</option>
              <option value="especialista">Especialista</option>
              <option value="gerente">Gerência</option>
              <option value="diretor">Diretoria</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Setor/Segmento</label>
            <input
              type="text"
              name="setor"
              value={formData.setor}
              onChange={onInputChange}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: Tecnologia, Saúde, Finanças"
            />
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">Empresa (opcional)</label>
            <input
              type="text"
              name="empresa"
              value={formData.empresa}
              onChange={onInputChange}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: Google, Hospital Albert Einstein"
            />
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-gray-700 font-semibold mb-2">Descrição da Vaga *</label>
          <textarea
            name="descricao"
            value={formData.descricao}
            onChange={onInputChange}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows="5"
            required
            placeholder="Cole aqui a descrição completa da vaga..."
          ></textarea>
        </div>

        <div className="mb-8">
          <label className="block text-gray-700 font-semibold mb-2">Seu Currículo Atual *</label>
          <FileUploader file={file} onFileChange={onFileChange} />
        </div>

        <div className="flex justify-between">
          <button 
            type="button" 
            onClick={onBack} 
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-lg transition duration-300"
          >
            Voltar
          </button>

          <button 
            type="submit" 
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!formData.cargo || !formData.nivel || !formData.descricao || !file}
          >
            Analisar Currículo
          </button>
        </div>
      </form>
    </div>
  );
};

export default FormScreen;
