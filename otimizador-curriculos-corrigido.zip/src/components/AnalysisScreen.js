import React from 'react';

const AnalysisScreen = ({ analysis, formData, onBack, onNewAnalysis }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-blue-800">Análise do Currículo</h2>
        <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 flex items-center">
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
          </svg>
          <span>Baixar Currículo Otimizado</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-bold text-lg text-blue-800 mb-2">📌 Vaga Alvo</h3>
          <p className="text-gray-700">{formData.cargo} – {formData.nivel} – {formData.setor}</p>
        </div>

        <div className="bg-yellow-50 p-4 rounded-lg">
          <h3 className="font-bold text-lg text-yellow-800 mb-2">🔎 Potencial Competitivo</h3>
          <div className="flex items-center">
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className="bg-yellow-500 h-4 rounded-full" 
                style={{ width: analysis.competitiveLevel === 'Alto' ? '90%' : analysis.competitiveLevel === 'Médio' ? '60%' : '30%' }}
              ></div>
            </div>
            <span className="ml-3 font-medium">{analysis.competitiveLevel}</span>
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="font-bold text-xl text-blue-800 mb-4">📋 Diagnóstico do Currículo Atual</h3>

        <div className="space-y-4">
          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-bold text-gray-800">1. Alinhamento com a vaga</h4>
            <p className="text-gray-700">{analysis.alignment}</p>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-bold text-gray-800">2. Estrutura e organização</h4>
            <p className="text-gray-700">{analysis.structure}</p>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-bold text-gray-800">3. Palavras-chave (ATS)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div>
                <p className="font-medium text-green-700">Presentes:</p>
                <ul className="list-disc list-inside text-gray-700">
                  {analysis.keywords.present.map((keyword, index) => (
                    <li key={index}>{keyword}</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="font-medium text-red-700">Ausentes sugeridas:</p>
                <ul className="list-disc list-inside text-gray-700">
                  {analysis.keywords.missing.map((keyword, index) => (
                    <li key={index}>{keyword}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-bold text-gray-800">4. Qualidade da escrita</h4>
            <p className="text-gray-700">{analysis.writing}</p>
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="font-bold text-xl text-blue-800 mb-4">🛠️ Propostas de Melhoria</h3>

        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-bold text-gray-800">Resumo Profissional</h4>
            <p className="text-gray-700">{analysis.improvements.summary}</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-bold text-gray-800">Experiência Profissional</h4>
            <p className="text-gray-700">{analysis.improvements.experience}</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-bold text-gray-800">Habilidades</h4>
            <p className="text-gray-700">{analysis.improvements.skills}</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-bold text-gray-800">Formação Acadêmica</h4>
            <p className="text-gray-700">{analysis.improvements.education}</p>
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="font-bold text-xl text-blue-800 mb-4">📎 Seções Sugeridas para Inclusão</h3>

        <div className="flex flex-wrap gap-2">
          {analysis.suggestions.map((suggestion, index) => (
            <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
              {suggestion}
            </span>
          ))}
        </div>
      </div>

      <div className="border-t pt-6 mt-8">
        <div className="flex justify-between">
          <button 
            onClick={onBack} 
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-lg transition duration-300"
          >
            Voltar
          </button>

          <button 
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300"
            onClick={onNewAnalysis}
          >
            Nova Análise
          </button>
        </div>

        <p className="text-center text-sm text-gray-500 mt-6">
          Agente desenvolvido por Ademi Bezerra | Especialista em Recursos Humanos
        </p>
      </div>
    </div>
  );
};

export default AnalysisScreen;
