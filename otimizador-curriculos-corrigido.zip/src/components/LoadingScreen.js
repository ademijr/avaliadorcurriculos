import React from 'react';

const LoadingScreen = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-lg text-gray-700">Analisando seu currículo...</p>
        <p className="text-sm text-gray-500 mt-2">Isso pode levar alguns instantes.</p>
      </div>
    </div>
  );
};

export default LoadingScreen;
