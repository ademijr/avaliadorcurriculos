import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';

// Componentes
import WelcomeScreen from './components/WelcomeScreen';
import FormScreen from './components/FormScreen';
import AnalysisScreen from './components/AnalysisScreen';
import LoadingScreen from './components/LoadingScreen';

function App() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    cargo: '',
    nivel: '',
    setor: '',
    empresa: '',
    descricao: '',
  });
  const [file, setFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (file) => {
    setFile(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulando processamento do servidor
    // Em produção, isso seria substituído por uma chamada real à API
    setTimeout(() => {
      setIsLoading(false);
      setAnalysis({
        alignment: 'O currículo apresenta experiências relevantes para a vaga, mas faltam conquistas mensuráveis.',
        structure: 'Estrutura clara, mas algumas seções poderiam ser reorganizadas para maior impacto.',
        keywords: {
          present: ['desenvolvimento', 'gestão', 'projetos', 'liderança'],
          missing: ['agile', 'scrum', 'KPIs', 'performance']
        },
        writing: 'Escrita formal e clara, mas poderia ser mais assertiva e orientada a resultados.',
        improvements: {
          summary: 'Adicionar um resumo profissional mais impactante focado em resultados.',
          experience: 'Quantificar conquistas e usar verbos de ação no início de cada item.',
          skills: 'Reorganizar habilidades por relevância para a vaga específica.',
          education: 'Destacar cursos e certificações relevantes para a posição.'
        },
        suggestions: ['Seção de projetos relevantes', 'Certificações em destaque', 'Idiomas com nível de proficiência'],
        competitiveLevel: 'Médio'
      });
      setStep(3);
    }, 3000);

    // Código para integração real com backend:
    /*
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('file', file);
      formDataToSend.append('data', JSON.stringify(formData));

      const response = await axios.post('https://sua-api.com/analyze', formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      setAnalysis(response.data);
      setIsLoading(false);
      setStep(3);
    } catch (error) {
      console.error('Erro ao analisar currículo:', error);
      setIsLoading(false);
      // Tratar erro
    }
    */
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-extrabold text-gray-900">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
              Otimizador de Currículos
            </span>
          </h1>
          <p className="mt-2 text-lg text-gray-600">Potencialize suas chances de sucesso com IA especializada</p>
        </div>

        {step === 1 && <WelcomeScreen onContinue={() => setStep(2)} />}
        {step === 2 && (
          <FormScreen 
            formData={formData}
            file={file}
            onInputChange={handleInputChange}
            onFileChange={handleFileChange}
            onSubmit={handleSubmit}
            onBack={() => setStep(1)}
          />
        )}
        {step === 3 && isLoading && <LoadingScreen />}
        {step === 3 && !isLoading && (
          <AnalysisScreen 
            analysis={analysis}
            formData={formData}
            onBack={() => setStep(2)}
            onNewAnalysis={() => window.location.reload()}
          />
        )}
      </div>
    </div>
  );
}

export default App;
