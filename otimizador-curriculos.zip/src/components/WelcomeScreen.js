import React from 'react';

const WelcomeScreen = ({ onContinue }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-blue-800">Bem-vindo ao Otimizador de Currículos</h2>
      <p className="mb-4">Sou um Especialista em Recrutamento, Seleção e Otimização de Currículos com 20 anos de experiência.</p>
      <p className="mb-6">Vou analisar seu currículo, verificar sua adequação à vaga desejada e entregar uma versão otimizada que maximizará suas chances de sucesso.</p>

      <div className="flex justify-center">
        <button 
          onClick={onContinue} 
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full transition duration-300 flex items-center"
        >
          <span>Começar Agora</span>
          <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
          </svg>
        </button>
      </div>
    </div>
  );
};

export default WelcomeScreen;
